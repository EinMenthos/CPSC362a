<?php
// Initialize the session
session_start();

// Check if the user is logged in, otherwise redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true ){
    header("location: login.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$current_credit = "";
$creditcard_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Check if amount is empty
    if(empty(trim($_POST["amount"]))){
        $amount_err = "Please enter an amount.";
    }
	else{
        $amount = trim($_POST["amount"]);
    	if (!is_numeric($amount)){
        	$amount_err = "Please enter a valid amount.";
        }
    	else{
        	if ($amount < 0){
            	$amount_err = "Please enter a positive amount.";
            }
            elseif ($amount > 1000000){
            	$amount_err = "The amount desired it too high. Please try an amount lower than one million.";
            }
            
        }
        //$amount = trim($_POST["amount"]);
    }

    // Check if credicard is empty
    if(empty(trim($_POST["creditcard"]))){
        $creditcard_err = "Please enter a credicard number.";
    } 
	
	 if(empty($amount_err) && empty($creditcard_err)){
	//else{
    	$creditcard = trim($_POST["creditcard"]);
    	if (is_numeric($creditcard)){
        	$new_amount = $amount + $_SESSION["credits"];
        	$sqlU = "UPDATE Users SET Credits = ? WHERE ID = ?";
        	if($stmtU = mysqli_prepare($link, $sqlU)){
            	mysqli_stmt_bind_param($stmtU, "sd", $param_amount, $param_id);     
            	$param_id = $_SESSION["id"];
                $param_amount = $new_amount;
            //echo $param_id;
            //echo $param_amount;
                	if(mysqli_stmt_execute($stmtU)){
                    	// Redirect to login page
                    	$creditcard_err = "Tuffycoins were added into your account!";
                    	$_SESSION["credits"] = $new_amount;
                	}
                	else{
                    	echo "Oops! Something went wrong. Please try again later.";
                	}
        	}
            mysqli_stmt_close($stmtU);                                    
        }
    	else {
        	$creditcard_err = "It was not possible to add Credits to your account.";
        }
    }
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Adding Tuffycoins</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Adding credits:</h2>
        <p>Username: <b><?php echo $_SESSION["username"]; ?></b></p>
        <p>Tuffycoins: <b><?php echo number_format($_SESSION["credits"], 2, '.', ','); ?></b></b></p>
        <p>Please enter your credit card number:</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
            <div class="form-group">
                <label></label>
                <input type="password" name="creditcard" class="form-control <?php echo (!empty($creditcard_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $creditcard; ?>">
                <span class="invalid-feedback"><?php echo $creditcard_err; ?></span>
            </div>
           	<div class="form-group">
                <label>Amount(plain number like 123.45)</label>
                <input type="text" name="amount" class="form-control <?php echo (!empty($amount_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $amount; ?>">
                <span class="invalid-feedback"><?php echo $amount_err; ?></span>
            </div>        
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a class="btn btn-link ml-2" href="login.php">Cancel</a>
            </div>
        </form>
    </div>    
</body>
</html>