<?php
// Include config file
require_once "config.php";
date_default_timezone_set( 'America/Los_Angeles' );
 
//I use this commando to monitor stuffs
//echo '<script>alert("', $Birthday, '")</script>';


// Define variables and initialize with empty values
$username = $password = $confirm_password = $Email = $Phone = $Address = $Interests = "";
$username_err = $password_err = $confirm_password_err = $Email_err = $Address_err = "";
$Credits = 0.00;
//still need to create those variables: address, phone#, interests, credits,
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT ID FROM Users WHERE Username = ?";
    	//SELECT * FROM Users WHERE Username = ?              -> retrieve all information from user aa
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

	// Validate First name
    if(empty(trim($_POST["FirstName"]))){
        $FirstName_err = "Please enter a First Name.";     
    } else{
        $FirstName = trim($_POST["FirstName"]);
        //echo $FirstName;
    }
	// Validate Last name
    if(empty(trim($_POST["LastName"]))){
        $LastName_err = "Please enter a Last Name.";     
    } else{
        $LastName = trim($_POST["LastName"]);
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
//increase the minimum size of the password later...
    } elseif(strlen(trim($_POST["password"])) < 1){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }

	//$Birthday = "2000-01-01";
    if(empty(trim($_POST["Birthday"]))){
        $Birthday_err = "Please select your birthday.";     
    } else{
        $Birthday = trim($_POST["Birthday"]);
   }
	//echo '<script>alert("', $Birthday, '")</script>';

//pick the time to set the account creation date
	$AccCreation = date("Y-m-d H:i:s");
	//echo '<script>alert("', $AccCreation, '")</script>';
        
//validate email from CSU
	if(empty(trim($_POST["Email"]))){
        $Email_err = "Please enter an email.";
    } else{
        $Email = trim($_POST["Email"]);
        $parts=explode('@', $Email);
    	//echo '<script>alert("',  $parts[0], '")</script>';
		//echo $parts[0];// username
		//echo $parts[1];// email.com
    	
        if ($parts[1] != 'csu.fullerton.edu' || $parts[0] == ''){
        	$Email_err = "Please enter an CSUF email.";
        	//$Email = ""; // removed to keep the previous value
        }
        else{
        
        
        // Prepare a select statement
        $sql = "SELECT ID FROM Users WHERE Email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_Email);
            
            // Set parameters
            $param_Email = trim($_POST["Email"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $Email_err = "This email is already being used. Try to recover the account.";
                } else{
                    $Email = trim($_POST["Email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
        
        
        
        
        }
   }
	//echo '<script>alert("', $Email, '")</script>';
//validate phone #
    if(empty(trim($_POST["Phone"]))){
        $Phone_err = "Please enter a phone number.";     
    }
	else{
    	$Phone = trim($_POST["Phone"]);
    	if(preg_match('/^[0-9]{10}+$/', $Phone)) {
		//echo "Valid Phone Number";
	} else {
		$Phone_err = "Invalid Phone Number";
        $Phone = "";
	}
    	
    
        //$Phone = trim($_POST["Phone"]);
    }
//validade address
	// Validate Last name
    if(empty(trim($_POST["Address"]))){
        $Address_err = "Please enter an Address.";     
    } else{
        $Address = trim($_POST["Address"]);
    }

    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($FirstName_err) && empty($LastName_err) && empty($Birthday_err) && empty($Email_err) && empty($Phone_err) && empty($Address_err)){
        
        // Prepare an insert statement
        //$sql = "INSERT INTO Users (Username, Password, FirstName, LastName, Birthday, AccountCreation) VALUES (?, ?, ?, ?, ?, ?)";
    	$sql = "INSERT INTO Users (Username, Password, FirstName, LastName, Birthday, AccountCreation, Email, Phone, Address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    	//Ïnsert into product_list (ID, description) Values ("1", "one")
    
    
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
        //ssss = string, string, string, string, each type for each variable
        //i	corresponding variable has type int
		//d	corresponding variable has type float
		//s	corresponding variable has type string, for dates, use string as '2009-04-30 10:09:00'
		//b	corresponding variable is a blob and will be sent in packets
            //mysqli_stmt_bind_param($stmt, "ssss", $param_username, $param_password, $param_fn, $param_ln);
		//mysqli_stmt_bind_param($stmt, "ssssss", $param_username, $param_password, $param_fn, $param_ln, $param_bd, 'now()');        
        mysqli_stmt_bind_param($stmt, "sssssssss", $param_username, $param_password, $param_fn, $param_ln, $param_bd, $param_creation, $param_email, $param_phone, $param_address);        
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
        	$param_fn = $FirstName;
            $param_ln = $LastName;
        	$param_bd = $Birthday;
        	$param_creation = $AccCreation;
        	$param_email = $Email;
        	$param_phone = $Phone;    
        	$param_address = $Address;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Sign Up</h2>
        <p>Please fill this form to create an account.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
<!-- adding more fields -->
            <div class="form-group">
                <label>FirstName</label>
                <input type="text" name="FirstName" class="form-control <?php echo (!empty($FirstName_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $FirstName; ?>">
                <span class="invalid-feedback"><?php echo $FirstName_err; ?></span>
            </div>        
            <div class="form-group">
                <label>LastName</label>
                <input type="text" name="LastName" class="form-control <?php echo (!empty($LastName_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $LastName; ?>">
                <span class="invalid-feedback"><?php echo $LastName_err; ?></span>
            </div>           
           <div class="form-group">
                <label>Birthday</label>
                <input type="date" name="Birthday" class="form-control <?php echo (!empty($Birthday_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Birthday; ?>">
                <span class="invalid-feedback"><?php echo $Birthday_err; ?></span>
            </div>
            <div class="form-group">
                <label>CSUF Email</label>
                <input type="text" name="Email" class="form-control <?php echo (!empty($Email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Email; ?>">
                <span class="invalid-feedback"><?php echo $Email_err; ?></span>
            </div>
            <div class="form-group">
                <label>Phone Number (numbers only)</label>
                <input type="text" name="Phone" class="form-control <?php echo (!empty($Phone_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Phone; ?>">
                <span class="invalid-feedback"><?php echo $Phone_err; ?></span>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="Address" class="form-control <?php echo (!empty($Address_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Address; ?>">
                <span class="invalid-feedback"><?php echo $Address_err; ?></span>
            </div>                 
                
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
            <p>Need to recover your account? <a href="confirm_email.php">Reset your password</a>.</p>
        </form>
    </div>    
</body>
</html>