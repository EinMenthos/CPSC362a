<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: welcome.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $FirstName = $LastName = $credits = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        //$sql = "SELECT id, username, password FROM users WHERE username = ?";
        $sql = "SELECT ID, Username, Password, FirstName, Locked, Credits FROM Users WHERE Username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
        	
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    //mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                	mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $FirstName, $Locked, $credits);

                    if(mysqli_stmt_fetch($stmt)){
                    
                		if ($Locked == "TRUE"){
                    		//echo '<script>alert("', $Locked, '")</script>';
                        	$login_err = "This Account is locked! Reset the password to unlock it!";
                    	}
                    	
                    	//else = account not locked
                    	else{
                        	if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["credits"] = $credits;
                            $_SESSION["username"] = $username;     
                        	$_SESSION["FirstName"] = $FirstName;
                        	unset($_SESSION['pw_tries']);
                            
                            // Redirect user to welcome page
                            header("location: welcome.php");
                        }
                        	else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        
                        	//just a simple counter in this session. don't need to save into DB
                        	session_start();
                        	if(isset($_SESSION["pw_tries"]) === true){
                            	if ($_SESSION["pw_tries"] < 2) {
    								$_SESSION["pw_tries"] += 1;
                                	echo '<script>alert("Number of tries: ', $_SESSION["pw_tries"], '")</script>';
                                }
                            
                           		elseif ($_SESSION["pw_tries"] == 2){
                                	//lock the account!!!
									//echo '<script>alert("locking account ', $username,'...")</script>';
                                
                                    
                        			$sqlU = "UPDATE Users SET Locked = 'TRUE' WHERE Username = ?";
                                	//echo '<script>alert("sql: ', $sqlU,'")</script>';
									if($stmtU = mysqli_prepare($link, $sqlU)){
                                    	mysqli_stmt_bind_param($stmtU, "s", $param_username);     
                                    	if(mysqli_stmt_execute($stmtU)){
                						// Redirect to login page
                                 		   	 $login_err = "Account is locked.";
            							} else{
                							echo "Oops! Something went wrong. Please try again later.";
            							}
                                    }
                                	mysqli_stmt_close($stmtU);
                                
                                
                                
                                	$_SESSION["pw_tries"] += 1;
                            	}

                            	else{
                                	//echo '<script>alert("This Account is locked! Reset The password to unlock it!")</script>';
                            	}
								
                            }
                            else{
                            	 $_SESSION["pw_tries"] = 1;
								echo '<script>alert("Number of tries: ', $_SESSION["pw_tries"], '")</script>';
                            	//$password_err = "Number of tries: " . $_SESSION["pw_tries"];
                                }
                        
                        }
                        
                        }
                    
                        
                    }
                }
            	else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            }
        	else{		//// Attempt to execute the prepared statement - FAILED
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Login</h2>
        <p>Please fill in your credentials to login.</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
            <p>Need to recover your account? <a href="confirm_email.php">Reset your password</a>.</p>
        </form>
    </div>
</body>
</html>