<?php

$sname= "localhost";

$unmae= "webapp";

$password = 'pa$$app';

$db_name = "TuffyBayDB";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

//if (!$conn) {
if (mysqli_connect_errno()) {

	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	//may remove
	exit();

}

?>