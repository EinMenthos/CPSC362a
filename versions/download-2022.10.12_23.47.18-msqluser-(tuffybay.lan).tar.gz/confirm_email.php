<?php
// Include config file
require_once "config.php";

$Email = "";
$Email_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	if(empty(trim($_POST["Email"]))){
        $Email_err = "Please enter an email.";
    }
	else{
        $Email = trim($_POST["Email"]);
        $parts=explode('@', $Email);
		//echo $parts[0];// username
		//echo $parts[1];// email.com
        if ($parts[1] != 'csu.fullerton.edu' || $parts[0] == ''){
        	$Email_err = "Please enter an CSUF email.";
        	//$Email = ""; // removed to keep the previous value
        }
        else{
        	// Prepare a select statement
        	$sql = "SELECT ID, Username FROM Users WHERE Email = ?";
        
        	if($stmt = mysqli_prepare($link, $sql)){
            
            	// Bind variables to the prepared statement as parameters
            	mysqli_stmt_bind_param($stmt, "s", $param_Email);
            
            	// Set parameters
            	$param_Email = trim($_POST["Email"]);
            
            	// Attempt to execute the prepared statement
            	if(mysqli_stmt_execute($stmt)){
                	/* store result */
                
                	mysqli_stmt_store_result($stmt);
                
                	if(mysqli_stmt_num_rows($stmt) == 1){
                		// found a valid email!!!
                		mysqli_stmt_bind_result($stmt, $id, $username);
                		if(mysqli_stmt_fetch($stmt)){
                        	//echo '<script>alert("', $id, '")</script>';
                        
                        
                        $sqlU = "UPDATE Users SET Locked = 'FALSE' WHERE ID = ?";
                                	//echo '<script>alert("sql: ', $sqlU,'")</script>';
						if($stmtU = mysqli_prepare($link, $sqlU)){
                        	mysqli_stmt_bind_param($stmtU, "s", $id);     
                            if(mysqli_stmt_execute($stmtU)){
                						// Redirect to login page
                							//header("location: login.php");
                            	//$login_err = "Account is unlocked.";
            							}
                        	else{
                            	echo "Oops! Something went wrong. Please try again later.";
            				}
                        }
                        mysqli_stmt_close($stmtU);
                        
                        
                    		session_start();
                			$_SESSION["loggedin"] = true;
                    		$_SESSION["id"] = $id;
                    		$_SESSION["username"] = $username;
	                		unset($_SESSION['pw_tries']);
                        
							//echo '<script>alert("', $_SESSION["reset_pw"], '")</script>';
  		              		header("location: reset-password.php");
                        }
        //echo '<script>alert("a2")</script>';
                		
                	
                	
 	               } else{
 	                   //$Email = trim($_POST["Email"]);
                    	$Email_err = "email not found.";
 	               }
 	           }
	        	else{
 	               echo "Oops! Something went wrong. Please try again later.";
 	           }
	
	            // Close statement
	            mysqli_stmt_close($stmt);
	        }
        }
   }

}
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Reset Password</h2>
        <p>Please fill in your credentials to reset the password.</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
             <div class="form-group">
                <label>Email</label>
                <input type="text" name="Email" class="form-control <?php echo (!empty($Email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Email; ?>">
                <span class="invalid-feedback"><?php echo $Email_err; ?></span>
            </div>               
                
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Reset">
            </div>
            <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
        </form>
    </div>
</body>
</html>