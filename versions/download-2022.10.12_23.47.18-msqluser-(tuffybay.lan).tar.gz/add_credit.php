<?php
//initialize functions
function validate_cc_number($cc_number) {
	// from https://www.codeguru.com/network/php-tip-validating-a-credit-card/
   /* Validate; return value is card type if valid. */
	//echo $cc_number;
	//echo gettype($cc_number);
   $false = false;
   $card_type = "";
   $card_regexes = array(
      "/^4\d{12}(\d\d\d){0,1}$/" => "visa",			//4532908939714062
      "/^5[12345]\d{14}$/"       => "mastercard",	//5156643641365711
      "/^3[47]\d{13}$/"          => "amex",			//376924083947595
      "/^6011\d{12}$/"           => "discover",		//6011463251253427
      "/^30[012345]\d{13}$/"     => "diners",		//3011970591113977
      "/^3[68]\d{14}$/"          => "diners",		//3608147118341345
   );

   foreach ($card_regexes as $regex => $type) {
//echo '<script>alert("', $regex, '")</script>';
       if (preg_match($regex, $cc_number)) {
       //echo '<script>alert("match")</script>';
           $card_type = $type;
           break;
       }
   }
   if (!$card_type) {
       return $false;
   }
   /*  mod 10 checksum algorithm  */
   $revcode = strrev($cc_number);
   $checksum = 0;
   for ($i = 0; $i < strlen($revcode); $i++) {
       $current_num = intval($revcode[$i]);
       if($i & 1) {  /* Odd  position */
          $current_num *= 2;
       }
       /* Split digits and add. */
           $checksum += $current_num % 10; if
       ($current_num >  9) {
           $checksum += 1;
       }
   }
   if ($checksum % 10 == 0) {
       return $card_type;
   } else {
       return $false;
   }
}


// Initialize the session
session_start();

// Check if the user is logged in, otherwise redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true ){
    header("location: login.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$current_credit = "";
$creditcard_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Check if amount is empty
    if(empty(trim($_POST["amount"]))){
        $amount_err = "Please enter an amount.";
    }
	else{
        $amount = trim($_POST["amount"]);
    	if (!is_numeric($amount)){
        	$amount_err = "Please enter a valid amount.";
        }
    	else{
        	if ($amount < 0){
            	$amount_err = "Please enter a positive amount.";
            }
            elseif ($amount > 1000000){
            	$amount_err = "The amount desired it too high. Please try an amount lower than one million.";
            }
            
        }
        //$amount = trim($_POST["amount"]);
    }

    // Check if credicard is empty
    if(empty(trim($_POST["creditcard"]))){
        $creditcard_err = "Please enter a credicard number.";
    }
	else{
		$creditcard = (string)trim($_POST["creditcard"]);
    	$creditcard_err = validate_cc_number($creditcard);
    	//echo '<script>alert("', $creditcard_err, '")</script>';
    	if ($creditcard_err == false){
        	$creditcard_err = "Please enter a valid credit card number.";
        }
    	else{
        	$creditcard_err = "";
        }
    }
	
	//echo $creditcard;
	//echo "type: ";
	//echo $creditcard_err;

	 if(empty($amount_err) && empty($creditcard_err)){
	//else{
    	$creditcard = trim($_POST["creditcard"]);
    	if (is_numeric($creditcard)){
        	$new_amount = $amount + $_SESSION["credits"];
        	$sqlU = "UPDATE Users SET Credits = ? WHERE ID = ?";
        	if($stmtU = mysqli_prepare($link, $sqlU)){
            	mysqli_stmt_bind_param($stmtU, "di", $param_amount, $param_id);     
            	$param_id = $_SESSION["userid"];
                $param_amount = $new_amount;
            //echo $param_id;
            //echo "\n";
           //echo $param_amount;
                	if(mysqli_stmt_execute($stmtU)){
                    	// Redirect to login page
                    	$creditcard_err = "Tuffycoins were added into your account!";
                    	$_SESSION["credits"] = $new_amount;
                	}
                	else{
                    	echo "Oops! Something went wrong. Please try again later.";
                	}
        	}
            mysqli_stmt_close($stmtU);                                    
        }
    	else {
        	$creditcard_err = "It was not possible to add Credits to your account.";
        }
    }
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Adding Tuffycoins</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Adding credits:</h2>
        <p>Username: <b><?php echo $_SESSION["username"]; ?></b></p>
        <p>Tuffycoins: <b><?php echo number_format($_SESSION["credits"], 2, '.', ','); ?></b></b></p>
        <p>Please enter your credit card number:
4532908939714062,
5156643641365711,
376924083947595,
6011463251253427,
3011970591113977,
3608147118341345
</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
            <div class="form-group">
                <label></label>
                <input type="password" name="creditcard" class="form-control <?php echo (!empty($creditcard_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $creditcard; ?>">
                <span class="invalid-feedback"><?php echo $creditcard_err; ?></span>
            </div>
           	<div class="form-group">
                <label>Amount(plain number like 123.45)</label>
                <input type="text" name="amount" class="form-control <?php echo (!empty($amount_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $amount; ?>">
                <span class="invalid-feedback"><?php echo $amount_err; ?></span>
            </div>        
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a class="btn btn-link ml-2" href="login.php">Cancel</a>
            </div>
        </form>
    </div>    
</body>
</html>